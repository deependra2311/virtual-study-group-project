
const connectorConfig = {
  connector: 'default',
  service: 'virtul-learning',
  location: 'us-central1'
};
exports.connectorConfig = connectorConfig;
